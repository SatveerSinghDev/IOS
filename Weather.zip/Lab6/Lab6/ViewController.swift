//
//  ViewController.swift
//  Lab6
//
//  Created by Group7 on 31/07/21.
//

import UIKit
import CoreLocation

struct WeatherData: Codable {
    let name: String
    let main: Main
    let weather: [Weather]
    let wind: Wind
}

struct Wind: Codable {
    let speed: Double
}

struct Main: Codable{
    let temp: Double
    let humidity: Int
}

struct Weather: Codable {
    let description: String
    let icon: String
}

class ViewController: UIViewController, CLLocationManagerDelegate {
    var manager: CLLocationManager?
    var urlString = ""
    
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var humidity: UILabel!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var wind: UILabel!
    
    var name: String = ""
    var cityDescription: String = ""
    var cityIcon: String = ""
    var cityTemperature: Double = 0.0
    var cityHumidity: Int = 0
    var windSpeed: Double = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        manager = CLLocationManager()
        manager?.delegate = self
        manager?.desiredAccuracy = kCLLocationAccuracyBest
        manager?.requestWhenInUseAuthorization()
        manager?.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else {
            return
        }
        // please select the location from locations option
        urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(location.coordinate.latitude)&lon=\(location.coordinate.longitude)&appid=3f800a4a6e26e881010fcf0f271e4187&units=metric"
        let urlSession = URLSession(configuration: .default)
        let url = URL(string: urlString)
        if let url = url {
            let dataTask = urlSession.dataTask(with: url) { (data, response, error) in
                if let data = data {
                    let jsonDecoder = JSONDecoder()
                    do {
                        let readableData =   try jsonDecoder.decode(WeatherData.self, from: data)
                        self.name = readableData.name
                        for i in readableData.weather {
                            self.cityDescription = i.description
                            self.cityIcon = i.icon
                        }
                        self.cityTemperature = readableData.main.temp
                        self.cityHumidity = readableData.main.humidity
                        self.windSpeed = readableData.wind.speed
                        DispatchQueue.main.async {
                            self.cityName.text = self.name
                            self.desc.text = self.cityDescription
                            self.temperature.text = "\(self.cityTemperature) °C"
                            self.humidity.text = "Humidity: \(self.cityHumidity)%"
                            self.wind.text = "Wind: \(self.windSpeed) km/h"
                            self.image.image  = UIImage(named: "\(self.cityIcon).png")
                        }
                    }
                    catch {
                        print(error)
                    }
                }
            }
            dataTask.resume()
        }
    }
}


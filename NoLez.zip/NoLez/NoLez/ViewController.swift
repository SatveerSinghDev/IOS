//
//  ViewController.swift
//  NoLez
//
//  Created by SATVEER SINGH on 06/08/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


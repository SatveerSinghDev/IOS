//
//  ScoreBoard.swift
//  NoLez
//
//  Created by SATVEER SINGH on 09/08/21.
//

import Foundation
class ScoreBoard : Identifiable {
    var date: Date
    var score: Int = 0
    var topic : String = ""
}

//
//  File.swift
//  NoLez
//
//  Created by user191302 on 8/8/21.
//

import Foundation

class Question {
    let question: String
    let optionA: String
    let optionB: String
    let optionC: String
    let optionD: String
    let answer: String
    
    init(question: String, optionA: String, optionB: String, optionC: String, optionD: String, answer: String){
        self.question = question
        self.optionA = optionA
        self.optionB = optionB
        self.optionC = optionC
        self.optionD = optionD
        self.answer = answer
    }
}

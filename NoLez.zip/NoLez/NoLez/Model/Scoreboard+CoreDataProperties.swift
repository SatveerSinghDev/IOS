//
//  Scoreboard+CoreDataProperties.swift
//  
//
//  Created by SATVEER SINGH on 09/08/21.
//
//

import Foundation
import CoreData


extension Scoreboard {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Scoreboard> {
        return NSFetchRequest<Scoreboard>(entityName: "Scoreboard")
    }

    @NSManaged public var score: Int64

    @NSManaged public var topic: String?

}

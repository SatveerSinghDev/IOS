//
//  File.swift
//  NoLez
//
//  Created by user191302 on 8/8/21.
//

import Foundation

struct Topic {
    var title : String
    var key : String
}

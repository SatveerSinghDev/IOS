//
//  QuizList.swift
//  NoLez
//
//  Created by user191302 on 8/8/21.
//

import Foundation

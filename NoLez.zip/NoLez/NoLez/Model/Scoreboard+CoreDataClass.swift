//
//  Scoreboard+CoreDataClass.swift
//  
//
//  Created by SATVEER SINGH on 09/08/21.
//
//

import Foundation
import CoreData

@objc(Scoreboard)
public class Scoreboard: NSManagedObject {

}

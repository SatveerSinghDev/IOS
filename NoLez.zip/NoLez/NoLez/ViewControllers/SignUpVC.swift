//
//  SignUpVC.swift
//  Nolez
//
//  Created by Kunal Gambhir on 07/08/2021.
//

import UIKit
import CoreData

//make model to save data
struct UserModel {
    var username : String?
    var Password : String?
    var ConfirmPassword : String?
}

class SignUpVC: UIViewController {

    @IBOutlet weak var userNameTextField: UITextField!// text field of user name
    
    @IBOutlet weak var passwordTextField: UITextField!// text field of password
    
    @IBOutlet weak var ConfirmPassword: UITextField!// text field of confirm user name
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // function to hide keyboard when click on other screen when keyboard open
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    // Save data locally
    private func saveDataInLocalStorage(instance: UserModel) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext // get context to save data
        //get entitiy to save data
        let entity = NSEntityDescription.entity(forEntityName: "SignUpData", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)//convet into NSManagedObject
        
        newUser.setValue(instance.username, forKey: "userName")// save user name with
        newUser.setValue(instance.Password, forKey: "password")//save password with keyboard
        newUser.setValue(instance.ConfirmPassword, forKey: "confirmPassword")//save confirm password with key
        do {
            try context.save()// save data
            print("Data Saved SuccessFully")
            self.navigationController?.popViewController(animated: true)// move to back screen
        } catch {
            print("Failed saving")// show failed message
        }
    }
    
    //signup Button Clicked
    @IBAction func SignUpBtnClicked(_ sender: UIButton) {
        //check all the fields anyone is not nil or empty
        if userNameTextField.text! == "" || passwordTextField.text! == "" || ConfirmPassword.text! == "" {
            //if empty show alert to fill fields
            let alert = UIAlertController(title: "ERROR!!!", message: "Please fill all the required Field", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        } else {
            //check both passwords are equal or not
            if passwordTextField.text! != ConfirmPassword.text! {
                //if not same show alert to user
                let alert = UIAlertController(title: "ERROR!!!", message: "please check password and confirm password are not same.", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(ok)
                self.present(alert, animated: true, completion: nil) // show alert
            } else {
                //make instance of model by saving user entered data
                let instance = UserModel(username: userNameTextField.text!, Password: passwordTextField.text!, ConfirmPassword: ConfirmPassword.text!)
                //call function by passing model data to function
                saveDataInLocalStorage(instance: instance)
                let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
                self.present(vc, animated: true, completion: nil)
            }
        }
    }
}

//
//  HomeViewController.swift
//  NoLez
//
//  Created by SATVEER SINGH on 07/08/21.
//

import UIKit

class HomeViewController: UIViewController, DisplayViewControllerDelegate {
    @IBOutlet weak var loginlabel: UILabel!
    @IBOutlet weak var prefLabel: UILabel!
    @IBOutlet weak var leadLabel: UILabel!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var city: UILabel!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var pref: UIButton!
    @IBOutlet weak var leaderboard: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func doSizeChange(data: CGFloat) {
        loginlabel.font = UIFont(name: loginlabel.font.fontName, size: data)
        prefLabel.font = UIFont(name: prefLabel.font.fontName, size: data)
    }
    
    func doLocationChange(cityloc: String, temperature: String, description: String) {
        desc.text = description
        city.text = cityloc
        temp.text = temperature
    }

    func changetheme(background: UIColor, textcolor: UIColor, labelbackgroundcolor: UIColor) {
        view.backgroundColor = background
        city.textColor = textcolor
        city.backgroundColor = labelbackgroundcolor
        temp.textColor = textcolor
        temp.backgroundColor = labelbackgroundcolor
        desc.textColor = textcolor
        desc.backgroundColor = labelbackgroundcolor
        login.setTitleColor(textcolor, for: .normal)
        login.backgroundColor = labelbackgroundcolor
        pref.setTitleColor(textcolor, for: .normal)
        pref.backgroundColor = labelbackgroundcolor
    }
    
    @IBAction func preferencetapped(_ sender: Any) {
        self.performSegue(withIdentifier: "home", sender: self)
    }

    @IBAction func loginTapped(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "navigation") as! UINavigationController
        self.present(vc, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "home") {
            let displayVC = segue.destination as! PreferencesViewController
            displayVC.delegate = self
        }
    }
}

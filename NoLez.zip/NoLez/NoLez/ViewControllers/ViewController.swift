//
//  ViewController.swift
//  Nolez
//
//  Created by Kunal Gambhir on 07/08/2021.
//

import UIKit
import CoreData

class ViewController: UIViewController, DisplayViewControllerDelegate {
    
    func changetheme(background: UIColor, textcolor: UIColor, labelbackgroundcolor: UIColor) {
        view.backgroundColor = background
    }
    
    func doSizeChange(data: CGFloat) {
        print(data)
    }
    
    func doLocationChange(cityloc: String, temperature: String, description: String) {
        print(cityloc)
    }
    
    func changetheme(background: UIColor, textcolor: UIColor) {
        view.backgroundColor = background
    }
    
    var window: UIWindow? // variable of main window
    @IBOutlet weak var userNameTxtField: UITextField! // text field of user name
    
    @IBOutlet weak var PasswordTxtField: UITextField! // text field of password
    var DataArry = [UserModel]() // array of saved data
    
    // MARKUP:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        if let _ = UserDefaults.standard.value(forKey: "userName") {
            // check if already login then move to home screen
            alreadylogin()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBar.isHidden = true // hide navigation bar
        fetchResultFromLocalStorage()// Get data from CoreData
    }

    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false//show navigation bar when move to other screen
    }
    
    //Fetch Local Data
    private func fetchResultFromLocalStorage() {
        self.DataArry.removeAll() //first empty the array
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext // get context to get data
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SignUpData") // get entity name where data is saved
        do {
            let result = try context.fetch(fetchRequest) //send request to get data
            for data in result as! [NSManagedObject] { //run a loop to get data
                let userName = data.value(forKey: "userName") as? String ?? ""
                let password = data.value(forKey: "password") as? String ?? ""
                
                let instance = UserModel(username: userName, Password: password, ConfirmPassword: "") // save data in model
                self.DataArry.append(instance) //save that model to array
            }
            print("Get Data SuccessFully")
        } catch {
            print("Failed")//if not save show message
        }
    }

    //login button pressed
    @IBAction func loginBtnPressed(_ sender: UIButton) {
        // check if any text field is empty show alert message
        if userNameTxtField.text! == "" || PasswordTxtField.text! == "" {
            // alert message
            let alert = UIAlertController(title: "ERROR!!!", message: "Please fill all the required Field", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        } else {
            // get data from array by running a loop
            for single in DataArry {
                // check user signup or not check data is saved in coredata or not if data is equal it means user signup
                if single.username == userNameTxtField.text! && single.Password == PasswordTxtField.text! {
                    //login successfully
                    //save data to check in future user already login are not
                    UserDefaults.standard.setValue(userNameTxtField.text!, forKey: "userName")
                    UserDefaults.standard.setValue(PasswordTxtField.text!, forKey: "password")
                    // navigate to welcome screen
                    let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "tabcontroller") as! UITabBarController
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
                }
            }
        }
    }
    
    @IBAction func signupButtonClicked(_ sender: UIButton) {
        // navigate to next screen
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.present(vc, animated: true, completion: nil)
    }

    //function of already login
    func alreadylogin() {
        //navigate to next screen
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "tabcontroller") as! UITabBarController
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }

    //function to hide keyboard when press on screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}


//
//  QuizViewController.swift
//  NoLez
//
//  Created by Mukunda Bhattarai on 8/8/21.
//

import UIKit
import FirebaseDatabase

class QuizViewController: UIViewController {
    
    var topic = ""
    
    let ref = Database.database().reference()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    @IBOutlet weak var questionCountLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionC: UIButton!
    @IBOutlet weak var optionD: UIButton!
    
    var quizList = [Question]()
    var questionNumber : Int = 0
    var score : Int64 = 0
    var answer : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        // fetch questions based on topic
        self.ref.child("categories/\(self.topic)/questions").observeSingleEvent(of: .value) { snapshot in
          for child in snapshot.children {
            if let snapshot = child as? DataSnapshot {
                let item = snapshot.value as? [String: Any]
                var options = [String]()
                let question = item?["question"] as? String ?? ""
                let optionSnap = snapshot.childSnapshot(forPath: "option")
                    for optionChild in optionSnap.children {
                        let optionChildSnap = optionChild as! DataSnapshot
                        let currentOption = optionChildSnap.value as? String
                        options.append(currentOption ?? "")
                    }
                options.shuffle()
                let correctAnswer = item?["answer"] as? String ?? ""
                let questionObject = Question(question: question,
                                              optionA: options[0],
                                              optionB: options[1],
                                              optionC: options[2],
                                              optionD: options[3],
                                              answer: correctAnswer);
                self.quizList.append(questionObject)
                print(item?["optionA"] as? String ?? "")
            }
          }
            self.quizList.shuffle()
            self.updateQuestion();
        }
    }
    

    // perfoms option selection operation
    @IBAction func selectOption(_ sender: UIButton) {
        if sender.currentTitle! == answer {
            score += 1
            scoreLabel.text = "Score: \(score)/10"
        }
        questionNumber += 1
        updateQuestion()
    }
    
    // change next question on Option selection
    func updateQuestion() {
        print("From Question")
        print(quizList)
        if quizList.count > 0 {
            if questionNumber < 10 {
                let questionObject = quizList[questionNumber]
                questionLabel.text = questionObject.question
                optionA.setTitle(questionObject.optionA, for: .normal)
                
                optionB.setTitle(questionObject.optionB, for: .normal)
                
                optionC.setTitle(questionObject.optionC, for: .normal)
                
                optionD.setTitle(questionObject.optionD, for: .normal)
                
                answer = questionObject.answer
                
                updateUI()
            }
            else {
                let scoreBoard = Scoreboard(context: self.context)
                scoreBoard.score = score
                scoreBoard.topic = topic
               
                
                do {
                    try self.context.save()
                }
                catch {
                    print(error)
                }
             
                let alert = UIAlertController(title: "Awesome! Your Score is \(score)/10", message: "", preferredStyle: .alert)
                            let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.dismissView()})
                            alert.addAction(restartAction)
                            present(alert, animated: true, completion: nil)
            }
        }
    }
    
    // Update UI with new question and options
    func updateUI() {
        questionCountLabel.text = "Question \(questionNumber + 1)/10"
        scoreLabel.text = "Score: \(score)"
    }
    
    // Go back
    func dismissView() {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
}

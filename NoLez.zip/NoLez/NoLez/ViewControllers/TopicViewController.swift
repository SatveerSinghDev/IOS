//
//  TopicViewController.swift
//  NoLez
//
//  Created by Mukunda Bhattarai on 8/7/21.
//

import UIKit
import FirebaseDatabase

class TopicViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var topicList: UITableView!
    let ref = Database.database().reference().child("categories")

    var items : [Topic] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topicList.delegate = self
        topicList.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.items = []
        // fetch categories from firebase and populate on tableview
        ref.observeSingleEvent(of: .value) { snapshot in
          for child in snapshot.children {
            if let snapshot = child as? DataSnapshot {
                print("Data:")
                let item = snapshot.value as? [String: Any]
                let title = item?["title"] as? String ?? ""
                let topic = Topic(title: title, key: snapshot.key)
                self.items.append(topic)
            }
          }
          self.topicList.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = topicList.dequeueReusableCell(withIdentifier: "topic", for: indexPath)
        let item = self.items[indexPath.row]
        cell.textLabel?.text = item.title
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = self.items[indexPath.row]
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let quizViewController = storyBoard.instantiateViewController(withIdentifier: "QuizViewController") as! QuizViewController
        quizViewController.topic = item.key
        quizViewController.modalPresentationStyle = .fullScreen
        self.present(quizViewController, animated: true, completion: nil)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}

//
//  ScoreBoardViewController.swift
//  NoLez
//
//  Created by Simranjit Kaur on 09/08/21.
//

import UIKit

class ScoreBoardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

        @IBOutlet weak var mytableView: UITableView!
        var change:UITextField?
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        var itemTODO = [String]()
        var items:[Scoreboard]?
    
    
        override func viewDidLoad() {
            super.viewDidLoad()
            mytableView.delegate = self
            mytableView.dataSource = self
            fetchscore()
        }
    
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(true)
            mytableView.delegate = self
            mytableView.dataSource = self
            fetchscore()
        }

    
        func fetchscore() {
            do {
                self.items = try context.fetch(Scoreboard.fetchRequest())
                DispatchQueue.main.async {
                    self.mytableView.reloadData()
                }
            }
            catch {
                print(error)
            }
        }

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return items!.count
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
            let score = self.items![indexPath.row]
            cell.textLabel?.text = "Topic: (\(score.topic!)), Score: \(score.score)"
            return cell
        }

        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
}

//
//  WelcomeScreenVC.swift
//  Nolez
//
//  Created by Kinjal Kaushik on 07/08/2021.
//

import UIKit

class WelcomeScreenVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
  
    @IBAction func logOutbtnClicked(_ sender: UIButton) {
        UserDefaults.standard.removeObject(forKey: "userName")
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        viewController.modalPresentationStyle = .fullScreen
        self.present(viewController, animated: true, completion: nil)
    }
}

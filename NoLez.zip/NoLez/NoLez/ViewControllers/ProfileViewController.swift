//
//  Profile.swift
//  Nolez
//
//  Created by Kinjal Kaushik on 8/9/21.
//

import UIKit
import CoreData

class Profile: UIViewController {
    
    // taking outlets for each field
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var contactNumber: UITextField!

    @IBOutlet weak var score: UILabel!
    
    // using core data UserProfile
    var signup:[SignUpData]?
    var user:[UserProfile]?
    
    // fetching view context
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    // using core data Scoreboard
    var scores:[Scoreboard]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetchUserDetails()
    }

    @IBAction func saveProfile(_ sender: UIButton) {
        // save user details to core data
        let entity = NSEntityDescription.entity(forEntityName: "SignUpData", in: context)
        let entityUser = NSEntityDescription.entity(forEntityName: "UserProfile", in: context)
        let signup = NSManagedObject(entity: entity!, insertInto: context)
        let user = NSManagedObject(entity: entityUser!, insertInto: context)
        user.setValue(name.text, forKey: "name")
        signup.setValue(username.text, forKey: "userName")
        user.setValue(contactNumber.text, forKey: "contactNumber")
        do {
            try self.context.save()
            let alert = UIAlertController(title: "Profile updated successfully", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        catch {
            print("Something went wrong!")
        }
        
        // close keyboard once done
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
    }
    
    // function to hide keyboard when click on other screen when keyboard open
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    func fetchUserDetails() {
        do {
            // fetching details from core data
            self.signup = try context.fetch(SignUpData.fetchRequest())
            self.user = try context.fetch(UserProfile.fetchRequest())
            self.scores = try context.fetch(Scoreboard.fetchRequest())
            // calculating highest score
            let data = self.scores!.enumerated().max(by: { (a, b) in
               (a.element.score) < (b.element.score)
            })
            // displaying the highest score
            if let data = data {
                self.score.text = String(format: "%d", data.element.score )
            }
            for (_,person) in self.signup!.enumerated() {
                username.text = person.userName
            }
            for (_,person) in self.user!.enumerated() {
                name.text = person.name
                contactNumber.text = person.contactNumber
            }
        }
        catch {
            print("Something went wrong!")
        }
    }
}

//
//  Scoreboard+CoreDataClass.swift
//  NoLez
//
//  Created by user191302 on 8/9/21.
//
//

import Foundation
import CoreData

@objc(Scoreboard)
public class Scoreboard: NSManagedObject {

}

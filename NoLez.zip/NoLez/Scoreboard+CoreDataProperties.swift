//
//  Scoreboard+CoreDataProperties.swift
//  NoLez
//
//  Created by user191302 on 8/9/21.
//
//

import Foundation
import CoreData


extension Scoreboard {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Scoreboard> {
        return NSFetchRequest<Scoreboard>(entityName: "Scoreboard")
    }

    @NSManaged public var score: Int64
    @NSManaged public var topic: String?

}

extension Scoreboard : Identifiable {

}

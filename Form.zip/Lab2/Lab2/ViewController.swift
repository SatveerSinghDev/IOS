//
//  ViewController.swift
//  Lab2
//
//  Created by user191302 on 6/4/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var country: UITextField!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var infoContainer: UITextView!
    @IBOutlet weak var infoLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func addButton(_ sender: UIButton) {
        // Add information on UITextView
        infoContainer.text = "Full Name: \(firstName.text ?? "") \(lastName.text ?? "")\n"
        infoContainer.text += "Country: \(country.text!)\n"
        infoContainer.text += "Age: \(age.text ?? "") \n"
        infoLabel.text = ""
        // Clear form after submission
        clear()
        // Hide keyboard
        self.view.endEditing(true)
        
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        if(firstName.text == "" || lastName.text == "" || country.text == "" || age.text == "") {
            infoLabel.text = "Complete missing info!"
        } else {
            infoLabel.text = "Successfully Submitted!"
        }
        self.view.endEditing(true)
    }
    
    @IBAction func clearButton(_ sender: UIButton) {
        clear()
        infoContainer.text = ""
        infoLabel.text = ""
        self.view.endEditing(true)
    }
    
    func clear() {
        firstName.text = ""
        lastName.text = ""
        country.text = ""
        age.text = ""
    }
}


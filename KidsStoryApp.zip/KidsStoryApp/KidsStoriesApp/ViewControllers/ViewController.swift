//
//  ViewController.swift
//  KidsStoryApp
//
//  Created by user191644 on 6/19/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var level1Button : UIButton!
    @IBOutlet var level2Button : UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "childrenn.png")!)
       
    }


    @IBAction func Level1(_ sender: UIButton) {
    }
    
    @IBAction func Level2(_ sender: UIButton) {
    }
}


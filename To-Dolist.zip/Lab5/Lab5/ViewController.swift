//
//  ViewController.swift
//  Lab5
//
//  Created by Group 7 on 16/07/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var myTableView: UITableView!
    
    var change:UITextField?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var items:[Item]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.delegate = self
        myTableView.dataSource = self
        fetchItems()
    }
    
    func fetchItems() {
        do {
            self.items = try context.fetch(Item.fetchRequest())
            DispatchQueue.main.async {
                self.myTableView.reloadData()
            }
        }
        catch {
            print("Something went wrong!")
        }
    }
    
    @IBAction func addButton(_ sender: UIButton) {
        showAlert()
    }

    func showAlert() {
        let alert = UIAlertController(title: "Add Item", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addTextField{ field in
            field.placeholder = "Write an Item"
        }
        alert.addAction(UIAlertAction(title: "Ok", style: .default) { (_) in
            let textfield = alert.textFields![0]
            let item = Item(context: self.context)
            item.name = textfield.text
            
            do {
                try self.context.save()
            }
            catch {
                print("Something went wrong!")
            }
            self.fetchItems()
        })
        
        present(alert, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        let item = self.items![indexPath.row]
        cell.textLabel?.text = item.name
        return cell
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selected = self.items![indexPath.row]
        let secondAlert = UIAlertController(title: "Edit Item", message: nil, preferredStyle: .alert)
        secondAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        secondAlert.addTextField()
        let textfield = secondAlert.textFields![0]
        textfield.text = selected.name
        secondAlert.addAction(UIAlertAction(title: "Update", style: .default){ (action) in
            selected.name = textfield.text
            do {
                try self.context.save()
            }
            catch {
                print("Something went wrong!")
            }
            self.fetchItems()
        })
        self.present(secondAlert, animated: true)
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .destructive, title: "Delete") { (action,view, completionHandler) in
            let itemRemove = self.items![indexPath.row]
            self.context.delete(itemRemove)
            do {
                try self.context.save()
            }
            catch {
                print("Something went wrong!")
            }
            self.fetchItems()
        }
        return UISwipeActionsConfiguration(actions: [action])
    }
}


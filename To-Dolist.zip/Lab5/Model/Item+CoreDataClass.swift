import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
